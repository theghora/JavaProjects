package coe318.lab7;
import java.util.Scanner;
import java.util.ArrayList;

/**
 * @author Taha Ghori
 */
public class UserMain {
    public static void main(String[] args) {
        Circuit cir = Circuit.getInstance();
        String s = "";
        while (!s.equals("spice") && !s.equals("end")) {
            Scanner scan = new Scanner(System.in);
            s = scan.next();
            if (s.equals("v") || s.equals("V")) {
                s = scan.next();
                s = scan.next();
                s = scan.next();
                double k = Double.valueOf(s);
                Node n1 = new Node();
                Node n2 = new Node();
                Source sr = new Source(n1, n2, k);
                cir.adds(sr);
            }
            if (s.equals("r") || s.equals("R")) {
                s = scan.next();
                s = scan.next();
                s = scan.next();
                double k = Double.valueOf(s);
                Node n1 = new Node();
                Node n2 = new Node();
                Resistor sr = new Resistor(k, n1, n2);
                cir.addr(sr);
            }
        }
        if (s.equals("end")) {
            System.out.println("\n"+"\t-ALL DONE-");
        } else if (s.equals("spice")) {
            System.out.println("\n"+cir+"\n\t-ALL DONE-");
        }
    }
}
