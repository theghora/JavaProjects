package coe318.lab7;
public class Node {
    private static int nums =0;
    private int nodenum=0;
    public Node() {
        nodenum = nums;
        nums += 1;
    }
    /**
     * 
     * @return returns the number that this node is
     */
    public int getNodenum() {
        return nodenum;
    }

    /**
     * @return Returns the Node as a string
     */
    @Override
    public String toString(){
        return ""+nodenum;
    }
}
